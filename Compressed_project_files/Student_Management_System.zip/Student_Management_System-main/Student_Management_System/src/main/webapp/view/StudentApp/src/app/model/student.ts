



export class Student{
    id : number=0;
    rollno : number=0;
    name:string='';
    dateOfAdmission : Date=new Date();
    physics:number=0;
    chemistry:number=0;
    biology:number=0;
    division:string='';
    result:string='';
    /*
 constructor(id:number,rollno:number,dateOfAdmission:string, name:string,physics:number,chemistry:number,biology:number,division:string,result:string) {
     this.id=id;
     this.rollno=rollno;
     this.name=name;
     this.dateOfAdmission=dateOfAdmission;
    
     this.physics=physics;
     this.chemistry=chemistry;
     this.biology=biology;
    
     this.division=division;
     this.result=result;


 }
 */

}