export class User {



  userid: number = 0;
  fname: String = '';
  lname: String = '';
  email:String='';
  phone: number = 0;
  address: String = '';  
  username: String='';
  password: String = '';
   confirmPassword:String='';

}